# Personal Portfolio Website

A modern, responsive personal portfolio website built with HTML, CSS, and vanilla JavaScript. This website serves as a central hub to introduce yourself and link to your various projects and interests.

## Features

- **Responsive Design**: Fully responsive layout that works on all devices
- **Modern UI**: Clean, professional design with smooth animations
- **Interactive Navigation**: Mobile-friendly navigation with smooth scrolling
- **Project Showcase**: Dedicated sections for games, writing, and other projects
- **Contact Integration**: Easy ways for visitors to connect with you
- **Performance Optimized**: Fast loading with optimized code

## Sections

1. **Hero Section**: Eye-catching introduction with call-to-action buttons
2. **About**: Personal information and skills showcase
3. **Projects**: Featured projects including games and writing
4. **Links**: Quick access to your various platforms and projects
5. **Contact**: Multiple ways for people to reach out

## Getting Started

### Prerequisites

- A modern web browser
- A text editor (VS Code, Sublime Text, etc.)
- Optional: A local web server for development

### Installation

1. Clone or download this repository
2. Open the project folder in your preferred text editor
3. Customize the content in `index.html` with your personal information
4. Update links and project information
5. Modify styling in `styles.css` if desired
6. Test the website by opening `index.html` in your browser

### Running Locally

#### Option 1: Direct File Opening
Simply double-click `index.html` to open it in your default browser.

#### Option 2: Local Web Server (Recommended)
For better development experience, use a local server:

```bash
# Using Python 3
python -m http.server 8000

# Using Node.js (if you have http-server installed)
npx http-server

# Using PHP
php -S localhost:8000
```

Then visit `http://localhost:8000` in your browser.

## Customization

### Personal Information
1. Update the title and meta tags in `<head>`
2. Replace "Your Name" throughout `index.html`
3. Update the hero section with your introduction
4. Modify the about section with your story
5. Replace placeholder email with your actual email

### Projects Section
Add your actual projects by updating the project cards:
- Update project titles and descriptions
- Add links to your game website, writing portfolio, etc.
- Replace placeholder links with actual URLs

### Links Section
Update the link cards with your actual social media and project links:
- GitHub profile
- LinkedIn profile
- Game website
- Writing portfolio
- Any other relevant links

### Styling
Customize the appearance in `styles.css`:
- Change the color scheme by updating CSS custom properties
- Modify fonts, spacing, and layout
- Add your personal branding elements

### JavaScript Features
The `script.js` file includes:
- Mobile navigation toggle
- Smooth scrolling
- Scroll animations
- Active navigation highlighting
- Performance optimizations

## Deployment

### GitHub Pages
1. Push your code to a GitHub repository
2. Go to repository Settings > Pages
3. Select source branch (usually `main` or `master`)
4. Your site will be available at `https://yourusername.github.io/repository-name`

### Netlify
1. Connect your GitHub repository to Netlify
2. Deploy automatically on every push
3. Custom domain support available

### Vercel
1. Connect your GitHub repository to Vercel
2. Automatic deployments and preview URLs
3. Excellent performance optimization

### Traditional Web Hosting
1. Upload all files to your web hosting provider
2. Ensure `index.html` is in the root directory
3. Update any absolute paths if necessary

## File Structure

```
portfolio-website/
├── index.html          # Main HTML file
├── styles.css          # CSS styling
├── script.js           # JavaScript functionality
├── README.md          # This documentation
└── assets/            # (Optional) Images, icons, etc.
```

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance

The website is optimized for performance with:
- Minimal external dependencies
- Optimized CSS and JavaScript
- Responsive images (add your own)
- Smooth animations with CSS transforms

## SEO Ready

- Semantic HTML structure
- Meta tags for social media sharing
- Proper heading hierarchy
- Alt text for images (add when you include images)
- Clean URLs and structure

## Contributing

This is a personal portfolio template, but feel free to:
1. Fork the repository
2. Make improvements
3. Submit pull requests for general enhancements

## License

This project is open source and available under the [MIT License](https://opensource.org/licenses/MIT).

## Next Steps

1. **Add Your Content**: Replace all placeholder content with your actual information
2. **Add Images**: Include your photo, project screenshots, and other visual content
3. **Test Thoroughly**: Check all links and functionality across different devices
4. **Deploy**: Choose a hosting platform and make your portfolio live
5. **Analytics**: Consider adding Google Analytics to track visitors
6. **SEO**: Optimize meta descriptions and add structured data

## Support

If you encounter any issues or have questions:
- Check the browser console for JavaScript errors
- Ensure all files are in the correct locations
- Validate your HTML and CSS
- Test on different browsers and devices

---

**Happy coding!** 🚀

Remember to personalize this portfolio to truly represent you and your work. The template provides a solid foundation, but your unique content and personality will make it shine.