# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project Overview

This is a personal portfolio website built with vanilla HTML, CSS, and JavaScript. It's a single-page application (SPA) with smooth scrolling navigation between sections. The site is designed to be fully responsive and performance-optimized.

## Architecture

### Core Structure
- **index.html**: Main HTML file containing all page sections (hero, about, projects, links, contact)
- **styles.css**: Complete styling with CSS custom properties, responsive design, and animations
- **script.js**: Vanilla JavaScript handling navigation, animations, scroll effects, and interactive features

### Design Patterns
- **Single-page application**: All content is in one HTML file with anchor-based navigation
- **Mobile-first responsive design**: CSS uses mobile breakpoints at 768px and 480px
- **Progressive enhancement**: Core functionality works without JavaScript, enhanced with JS features
- **CSS custom properties**: Uses CSS variables for consistent theming and easy customization

### Key Features
- **Intersection Observer API**: Used for scroll-triggered fade-in animations
- **Smooth scrolling**: Custom implementation with offset for fixed navbar
- **Mobile navigation**: Hamburger menu with toggle functionality
- **Active section highlighting**: Navigation links highlight based on current scroll position
- **Performance optimization**: Debounced scroll handlers and passive event listeners

## Development Commands

### Local Development
```bash
# Serve locally (recommended approach)
python -m http.server 8000          # Python 3
npx http-server                     # Node.js
php -S localhost:8000              # PHP

# Simple file opening (basic testing only)
# Double-click index.html or open directly in browser
```

### Validation and Testing
```bash
# HTML validation (if validator installed)
html-validator index.html

# CSS validation
css-validator styles.css

# JavaScript linting (if ESLint configured)
eslint script.js
```

## File Structure

```
portfolio-website/
├── index.html          # Complete single-page application
├── styles.css          # All styling and responsive design
├── script.js           # Interactive features and animations
├── README.md           # Comprehensive setup and customization guide
└── WARP.md            # This file
```

## Technical Considerations

### JavaScript Features
- All functionality is in vanilla JS (no frameworks/libraries)
- Modular event handlers for different features
- Performance-optimized scroll handling with debouncing
- Intersection Observer for smooth animations
- Console logging for development guidance

### CSS Architecture  
- Uses modern CSS features (custom properties, flexbox, grid)
- Mobile-first responsive approach
- Smooth transitions and hover effects throughout
- Fixed navigation with backdrop-filter blur effect

### Browser Support
Targets modern browsers with support for:
- CSS Grid and Flexbox
- Intersection Observer API
- CSS custom properties
- Backdrop-filter (with fallbacks)

## Deployment Notes

The site is deployment-ready for static hosting platforms:
- **GitHub Pages**: Direct deployment from repository
- **Netlify/Vercel**: Zero-config deployment
- **Traditional hosting**: Upload all files to web root

No build process or dependencies required - all files can be served directly.